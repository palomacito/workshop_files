#####################################################################
# ref: https://python-packaging.readthedocs.io/en/latest/minimal.html
#####################################################################

from setuptools import setup, find_packages

with open("README.md", "r") as fh:
    long_description = fh.read()

with open("requirements.txt", "r") as fh:
    dependencies = fh.readlines()
dependencies = [dep.replace("\n", "") for dep in dependencies]


setup(
    name="chuv_supertoolbox",
    version="0.0.6.6",
    description="Toolbox for DWH basic operations",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://gitlab.itrcs3-app.intranet.chuv/datascience/chuv_supertoolbox",
    author="Jeremie Despraz, Paloma Cito",
    author_email="paloma.cito@chuv.ch",
    license="",
    packages=["chuv_supertoolbox"],
    install_requires=dependencies,
    python_requires=">=3.6",
    zip_safe=False,
)
