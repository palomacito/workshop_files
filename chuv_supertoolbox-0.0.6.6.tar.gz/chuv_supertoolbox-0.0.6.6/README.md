# Chuv_supertoolbox

[![pipeline status](http://gitlab.itrcs3-app.intranet.chuv/datascience/toolbox/badges/develop/pipeline.svg)](http://gitlab.itrcs3-app.intranet.chuv/datascience/chuv_supertoolbox/-/commits/develop)

<img src="https://t3.ftcdn.net/jpg/02/95/66/38/360_F_295663843_jow7iOnHh9avVJI1dKtOXtUqCMTCmqMM.jpg" width="200">

**CHUV-supertoolbox** is a Python module built to facilitate research at CHUV by providing simple operations on the DWH-RC data. Find the complete documentation [here](https://datascience.gitlab-pages.itrcs3-app.intranet.chuv/chuv_supertoolbox/index.html).

## Table of contents
- [Getting Started](#getting-started)
    - [Installing the library](#installing)
    - [Basic Usage](#basic-usage)
- [Features at a Glance](#features-at-a-glance)
    - [Data warehouse connection and query](#connection)
    - [Data preprocessing](#preprocessing)
    - [Preprocessing utils](#preprocessing-utils)
    - [Imputation](#imputation)
    - [Plotting](#plotting)
    - [Feature Extraction](#feature-extraction)
    - [Text processing](#text-processing)
    - [Temporal data processing](#temporal-data-processing)
    - [Training](#training)


## Getting started

### Installing the library

If you want to start working with CHUV-supertoolbox you can install the library and import it to your project.
<br>
Requirement: CHUV-supertoolbox requires Python >= 3.6.
<br>

```
pip install --upgrade --trusted-host pypiserver.itrcs3-app.intranet.chuv --index-url https://pypiserver.itrcs3-app.intranet.chuv/simple/ chuv-supertoolbox
```
<br>

**Attention**
<br>
If you are using Python 3.8 or 3.10 you will need to do this additional step in a terminal in order to use the DWHConnector:

```
conda install pyodbc
```

Note:  pulling the package from the local Pypi server requires credentials. If you don't have them, send an email at jeremie.despraz@chuv.ch.


### Basic Usage

Once you have the package set up you can start using *supertoolbox* by creating an object:

```python
from chuv_supertoolbox.imputation import StandardImputation

imputation = StandardImputation(imputation_model_name='knn')
imputed_df = imputation.fit_transform(df)
```

Most modules follow the fit-transform format.
<br>
Please find a simple tutorial [here](tutorial/README.md).

The other available methods are described in the next section.


## Features at a glance

### Connection and query to the data warehouse

The module `DWHConnector` in `dwhconnector.py` allows you to connect to the data warehouse by simply providing the path to the file containing your credentials on your machine.

```python
from chuv_supertoolbox.dwhconnector import DWHConnector

connector = DWHConnector(secrets_path='home/user/secrets')
df = connector.sql_query('SELECT * FROM TABLE')
```

If the query contains several WHERE parameters, `sql_query_long` can be used instead of `sql_query`.

### Data preprocessing

In the `encoding.py` file you'll find several preprocessing modules.

#### OneHotEncoder

This module transforms the dataset by one-hot encoding specific features in a dataframe.

```python
from chuv_supertoolbox.encoding import OneHotEncoder

encoder = OneHotEncoder(columns=['age','color'])
df = encoder.fit_transform(df)
```

#### DuplicatesRemover

This module returns the input dataframe without any duplicated index. It will keep the row index with least NaN values.

```python
from chuv_supertoolbox.encoding import DuplicatesRemover

duplicates_remover = DuplicatesRemover()
df = duplicates_remover.fit_transform(df)
```

#### ColumnsExtract

This module returns the input dataframe where given keywords have been extracted and reshaped into new columns.

```python
from chuv_supertoolbox.encoding import ColumnsExtract

column_extract = ColumnsExtract(col_keywords=['list of (column,value) tuples'])
df = duplicates_remover.fit_transform(df)
```

#### ZNormalizer

This module normalizes the data such that the mean is 0 and the standard deviation is 0.

```python
from chuv_supertoolbox.encoding import ZNormalizer

normalizer = ZNormalizer()
df = normalizer.fit_transform(df)
```

#### MinMaxNormalizer

This module normalizes the data such that the minimum is 0 and the maximum is 1.

```python
from chuv_supertoolbox.encoding import MinMaxNormalizer

normalizer = MinMaxNormalizer()
df = normalizer.fit_transform(df)
```

#### CategoryCleaner

This module removes categorical data not present in the top `thres` percentile of the input data. Discarded categories are indicated with the `Other` label.


```python
from chuv_supertoolbox.encoding import CategoryCleaner

cleaner = CategoryCleaner(columns=['medication','ethnicity'])
df = cleaner.fit_transform(df)
```

#### ParallelApply

This module applies a function `func` to the entire dataframe using multiple threads. For a grouped dataframe, use the `grp=True` parameter. If the function `func` takes additional parameters (not just the dataframe), one can use the `params` parameter.

```python
from chuv_supertoolbox.encoding import ParallelApply

def f(df):
  return df + 3

parallel = ParallelApply(func=f)
df = parallel.fit_transform(df)
```

Now let's say we want to group a dataframe by country and add 1000 dollars to the PIB of each country:

```python
from chuv_supertoolbox.encoding import ParallelApply

def f(df, col, x):
  df[col] = df[col] + x
  return df

grouped_df = df.groupby('country')
parallel = ParallelApply(func=f, params=('PIB', 1000),grp=True)
result = parallel.fit_transform(grouped_df)
```


### Preprocessing utils

The `preprocessing.py` file contains preprocessing methods that can be used on CHUV data:
* `get_most_common`: returns the most common values appearing in a column up to a specified cutoff.
* `get_sorted_val`: returns the values with the highest (or lowest) values in a goal column appearing in the column 'column'.
* `soarian_dependances_to_scores`: Returns a transformed dataframe where the dependances finding identified by 'finding_code' has been replaced by its numerical values (specific to CHUV data).

### Imputation

In the `imputation.py` file, we have different imputation modules available.

#### BasicImputation

This module provides simple backward and forward filling imputation.

```python
from chuv_supertoolbox.imputation import BasicImputation

imputation = BasicImputation()
df = imputation.fit_transform(df)
```

#### StandardImputation

This modules lets the user choose between three different imputation methods : K-nearest neighbors, MissForest and MICE.

```python
from chuv_supertoolbox.imputation import StandardImputation

imputation = StandardImputation(ïmputation_model_name='knn',n_neighbors=5)
df = imputation.fit_transform(df)
```

### Plotting

In `plotting.py` you can find different plotting methods to visualize your dataframe distribution.
* `plot_histogram`: Plots a histogram where bars are sorted from most common to least common.
```python
from chuv_supertoolbox.plotting import *

plot_histogram(df=df,col_name='duree_sejour')
```
* `col_boxplot`: Plots a histogram of the goal column grouped by a specific column.
```python
from chuv_supertoolbox.plotting import *

col_boxplot(data=df, goal_col='duree_sejour',grouping_col='numero_sejour_code')
```
* `plot_importance`: Plot a barplot representing the importance of each feature in a sklearn prediction model (e.g. random forest). The importance is normalized on a [0, 1] scale.
```python
from chuv_supertoolbox.plotting import *

model = LinearRegression()
model.fit(X,y)
plot_importance(coeffs=model.coef_, col_labels=')
```

### Feature extraction

This module contains a function `select_discriminative_feature` that writes and if necessary plots features from the input dataframe that are statistically discriminant for a given `y` (label) target value.

```python
from chuv_supertoolbox.feature_extraction import *

select_discriminative_feature(df_soa, target_col='fnd_code', value_col='fnd_value',
                      lib_col='fnd_libelle', time_col='obsv_dt', y_col='duree_sejour', data_type='categorical',
                      fname='feature_selection/features_soarian.csv')

```

### Text Processing
In `textprocessing.py` you can find several methods for text processing.
* `load_stopwords`: reads a file containing stopwords and returns them in form of a list of string.
* `tokenize_text`: tokenizes the input text.
* `unique_tokens`: returns an array of unique tokens from an input text string.
* `normalize_text`: returns a normalized text string, i.e. where all text has been standardized (lowercased, deaccentuated, and tokenized).
* `normalize_df_column`: applies `normalize_text`to an entire column.
* `fuzzysearch_indices`: Returns boolean indicators where a string was matched in a given dataframe column. The level of fuzziness can be set using the `level` variable.
* `replace_with_stem`: inplace replacement of given words with a new word in the column of interest.
* `replace_with_lemma`: returns the input text where all of the tokens have been replaced by their lemma (root).
* `create_bow`: "Returns a bag-of-word (BOW) object from from a dataframe.
* `get_text`: Returns a dataframe column text content in normalized format. Possibility of matching with keywords.
* `text_to_bow_idx`: Returns BOW indices corresponding to each words in the dataframe column.
* `text2vec`: Returns the vector corresponding to a text, where the vector components are aggregated using a specified method.
* `col2vec`: Returns the original dataframe with an additional column containing the aggregated Word2Vec representation of the text in the specified column.


### Temporal data processing

In the `timedevents.py` file, we have several methods to deal with temporal data (meaning dataframes with one row per observation, e.g many rows per patient with each row corresponding to a lab result or medical observation).

* `get_first_of`: returns the first occurrence of a measurement within a group.
* `get_last_of`: returns the last occurrence of a measurement within a group.
* `get_nth_of`: returns the nth occurrence of a measurement within a group.
* `extract_timed_data`: returns a chronologically ordered table  containing as columns specified codes that appear in the
    original 'target_col' column. The data goes back a fixed number of steps in the past. All columns have a suffix format with first the code and then the time step.
* `get_previous_stays`: returns the previous stays in chronological order.
* `compute_nb_events`: returns the number of occurrences of an event between two dates (e.g the number of occupied beds).
* `days_to_next_holiday`: returns the number of days remaining until a holiday in the Canton of Vaud from a given date.
* `compute_dow_month_holiday`: returns a dataframe where 5 new columns are added: weekday, month, holiday, vacation, days_to_next_holiday.
* `compute_time_of_day`: returns a new dataframe containing the time of day in a circular format or in normal format.
* `remove_time_from_datetime`: returns a datetime object that contains only date information and no time (i.e. hours, minutes, seconds).
* `get_idxmin`: returns the index of the timestamp t closest to the specified reference.
* `get_nearest_value`: returns a DataFrame containing the closest row in the dataframe with respect to the provided timsetamp. Using a grouper allows the function to return multiple rows corresponding to the desired groups.
* `get_timeseries`: returns a timeseries in a dataframe format. All values are aggregated into a row for each grouper instance using the 'agg_func' function(s) over the desired time period defined by 'freq'. This is highly useful for temporal medical data like lab results or medical measurements.
* `fill_with_nearest`: returns the original measurements in the dataframe and the aggregated closest neighbor measurements as new columns.
* `time_rolling_window`: returns a DataFrame containing rolling window values of the target columns representing the state of the dataframe for each specified period of time.
* `grptime_rolling_window`: Same as above but with a grouped dataframe.
* `data_in_interval`: returns the rows of the input dataframe that are in the desired temporal interval with respect to specified date. Forward_only and backward_only flags can further restrict the interval properties.


### Training
The `training.py` file contains different classes to assist machine learning training.

#### CrossvalPredict

This module allows the user to perform Cross Validation prediction on a specified model which can be either a neural network or a model from the sklearn library. The user can specify the number of epochs, the batch size, etc.

```python
from chuv_supertoolbox.training import CrossValPredict

model = LinearRegression()
crossvalpredict = CrossValPredict(model=model,y=y)
preds = crossvalpredict.fit_transform(X)
```

The user can also request the CrossValPredict object to return the last fitted model of the k folds.

```python
from chuv_supertoolbox.training import CrossValPredict

model = LinearRegression()
crossvalpredict = CrossValPredict(model=model,y=y, return_model=True)
fitted_model,preds = crossvalpredict.fit_transform(X)
```

#### ClassEqualizer

This class balances the different classes such that they are all equally represented. Let's say `y` is the target output with 1000 times 'dog', 1000 times 'cat' and 100 times 'bird'. We want 'bird to be equally represented.

```python
from chuv_supertoolbox.training import ClassEqualizer

classequalizer = ClassEqualizer(y=y, label='bird')
X = classequalizer.fit_transform(X)
```

#### PipelineComposer

This class allows the user to perform several steps in a row on a dataset as long as the steps all follow the fit-transform format.

```python
from chuv_supertoolbox.training import PipelineComposer

cleaning_pipeline = PipelineComposer(cat_cleaner_04,cat_cleaner_05,cat_cleaner_07,cat_cleaner_08,cat_cleaner_09,onehotencoder)
X = cleaning_pipeline.fit_transform(X)
```

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.
