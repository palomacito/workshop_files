"""
Imputation methods
"""
# Necessary packages
import numpy as np
import pandas as pd

# Static imputation
import sklearn.neighbors._base
import sys

sys.modules["sklearn.neighbors.base"] = sklearn.neighbors._base
from missingpy import MissForest

from sklearn.experimental import enable_iterative_imputer
from sklearn.impute import KNNImputer, IterativeImputer


class ForwardBackwardFill:
    """Forward and backward filling to fill missing values.
    Example::
        imputation = ForwardBackwardFill()
        df = imputation.fit_transform(df)
    """

    def __init__(self):
        """Constructor of ForwardBackwardFill"""
        pass

    def _impute(self, x):
        """Filling of missing values by both backward and forward filling.

        :param x: row to fill
        :return: imputed dataframe
        """
        x = x.fillna(method="bfill")
        x = x.fillna(method="ffill")
        return x

    def fit_transform(self, dataset):
        """Return  imputed dataset.

        :param dataset: incomplete dataset
        :return: imputed dataset
        """
        return dataset.apply(self._impute)


class StandardImputation:
    """Standard imputation method for static data. Offers KNN, Mice and Missforest imputation.
    Example::
        imputation = StandardImputation(ïmputation_model_name='knn')
        df = imputation.fit_transform(df)

    :param imputation_model_name: imputation model ('mice', 'missforest', 'knn')
    :param n_neighbors: numbers of neighbors to consider for knn
    :param weigths: distance measure
    :param impute_val: the name of a value if we want to impute another value than NaN
    """

    def __init__(
        self,
        imputation_model_name,
        n_neighbors=5,
        weights="distance",
        impute_val=None,
    ):
        """Constructor for StandardImputation

        :param imputation_model_name: imputation model ('mice', 'missforest', 'knn')
        :param n_neighbors: numbers of neighbors to consider for knn
        :param weigths: distance measure
        :impute_val: the name of a value if we want to impute another value than NaN
        """
        # Only allow for certain options
        assert imputation_model_name in ["mice", "missforest", "knn"]
        self.imputation_model_name = imputation_model_name
        # Initialize the imputation model
        self.imputation_model = None
        self.n_neighbors = n_neighbors
        self.weights = weights
        self.impute_val = impute_val

    def _rounding(self, data, data_imputed):
        """Use rounding for categorical variables.

        :param data: incomplete original data
        :param data_imputed: complete imputed data
        :return data_imputed: imputed data after rounding
        """
        for i in range(data.shape[1]):
            # If the feature is categorical (category < 20)
            if len(np.unique(data[:, i])) < 20:
                # If values are integer
                if np.all(
                    np.round(data[:, i][~np.isnan(data[:, i])])
                    == data[:, i][~np.isnan(data[:, i])]
                ):
                    # Rounding
                    data_imputed[:, i] = np.round(data_imputed[:, i])

        return data_imputed

    def _fit(self, dataset):
        """Fit the standard imputation model.

        :params dataset: incomplete dataset
        """
        # MICE
        if self.imputation_model_name == "mice":
            self.imputation_model = IterativeImputer()
        # MissForest
        elif self.imputation_model_name == "missforest":
            assert dataset.shape[1] >= 2
            self.imputation_model = MissForest()
        # KNN
        elif self.imputation_model_name == "knn":
            self.imputation_model = KNNImputer(
                n_neighbors=self.n_neighbors,
                weights=self.weights,
            )

        self.imputation_model = self.imputation_model.fit(dataset)
        return

    def _transform(self, dataset):
        """Return imputed dataset by standard imputation.

        :params dataset: incomplete dataset
        :return: imputed dataset by imputation model.
        """
        assert self.imputation_model is not None

        # Standard imputation
        data_imputed = self.imputation_model.transform(dataset)

        # Rounding
        dataset_arr = self._rounding(dataset.to_numpy(), data_imputed)

        dataset_arr = pd.DataFrame(
            dataset_arr, index=dataset.index, columns=dataset.columns
        )

        return dataset_arr

    def fit_transform(self, dataset):
        """Return imputed dataset by standard imputation.

        :params dataset: incomplete dataset
        :return: imputed dataset by imputation model.
        """
        # if it is not NaN values that we want to replace but another specific value
        if self.impute_val is not None:
            # replace all these values by nan so they can be imputed
            dataset = dataset.replace(self.impute_val, np.nan)

        # remove complete null columns as they will be removed by the imputation model
        null_cols = dataset.columns[dataset.isnull().all(axis=0)]
        non_null_cols = [x for x in dataset.columns if x not in null_cols]
        dataset = dataset[non_null_cols]

        self._fit(dataset)
        return self._transform(dataset)
