"""
.. moduleauthor:: Paloma Cito <paloma.cito@chuv.ch>
.. automodule:: myproject.main
   :members:
"""
